import { Member, Task } from "../models/types";

export const members: Member[] = [
  { id: "m1", name: "Brandon" },
  { id: "m2", name: "Alice" },
  { id: "m3", name: "Bob" }
];

export const tasks: Task[] = [];
